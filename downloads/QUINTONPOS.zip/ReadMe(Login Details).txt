                                                      FFFFFF           FFFFFFFFF          FFFFF           FFFFFFF
                                                    FF      FF         FF       FF      FF     FF        FF
                                                   FF        FF        FF        FF    FF       FF      FF
                                                   FF        FF        FF       FF    FF         FF     FF 
                                                   FF        FF        FF     FF      FF         FF       FFFFFF
                                                   FF   FF   FF        FF FFFF        FF         FF             FF
                                                   FF     FF FF        FF             FF         FF              FF
                                                    FF      FF         FF             FF        FF               FF
                                                      FFFFFF  FF       FF              FF      FF               FF
                                                               FF      FF                FFFFFF          FFFFFFF
                          


Admin Accounts Credentials:------------------------------------------|
|                                                                    |
| Username >> Pacoz                                                  |
| Password >> Pacoz@101                                              |
|--------------------------------------------------------------------|
| Username >> NattyB                                                 |
| Password >> natty@@4                                               |
|--------------------------------------------------------------------|


Standard Accounts Credentials:---------------------------------------|
|                                                                    |
| Username >> Brown                                                  |
| Password >> mulungu01                                              |
|--------------------------------------------------------------------|
| Username >> Kim                                                    |
| Password >> kim01                                                  |
|--------------------------------------------------------------------|
| Username >> Ene                                                    |
| Password >> chipo01                                                |
|--------------------------------------------------------------------|
| Username >> melloe                                                 |
| Password >> melloe01                                               |
|--------------------------------------------------------------------|

NB: USERNAMES AND PASSWORDS ARE CASE SENSETIVE!!!